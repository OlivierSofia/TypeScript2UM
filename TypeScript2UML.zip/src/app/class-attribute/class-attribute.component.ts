import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-class-attribute',
  templateUrl: './class-attribute.component.html',
  styleUrls: ['./class-attribute.component.css']
})
export class ClassAttributeComponent implements OnInit {
  attributeName:string;
  attributeType:string;
  
  constructor() { }

  ngOnInit(): void {
  }

}

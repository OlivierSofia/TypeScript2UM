
import { HttpClient } from '@angular/common/http';

import { Injectable} from "@angular/core";

@Injectable({
    providedIn: 'root'
})

export class UtilsService {

    public BASE_SERVER_URL = 'http://localhost:4000';

    public POST_SERVER_URL = this.BASE_SERVER_URL+'/post';

    public tsClassFileName = "tsClassFileName.ts";

    constructor(private httpClient: HttpClient) { }

    

}
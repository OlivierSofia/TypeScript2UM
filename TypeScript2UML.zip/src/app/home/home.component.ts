import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { stringify } from '@angular/compiler/src/util';

import { UtilsService } from '../services/utils.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  fileData: File = null;
  content: any = null;
  uploadedFilePath: string = null;
  className: string;

  attributes=[{name:"attr11",type:"int"},{name:"attr12",type:"string"},{name:"attr13",type:"string"}];
  methods=[{name:"method1",params:[{name:"mattr11",type:"int"},{name:"mattr12",type:"int"}],resultType:"object"},
  {name:"method2",params:[{name:"mattr21",type:"int"},{name:"mattr22",type:"int"}],resultType:"int"}];

  constructor(private utilsService: UtilsService, private httpClient: HttpClient) { }

  ngOnInit(): void {
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
    this.preview();
  }

  //setting the file content to display it
  preview() {

    let fileReader = new FileReader();
    //    fileReader.onload = (e) => {
    //      console.log(fileReader.result);
    //    }
    fileReader.readAsText(this.fileData);
    fileReader.onload = (_event) => {
      this.content = fileReader.result;
    }
  }

  //send the selected file to the server to store it 
  //in order to reuse it later on
  onSubmit() {
    //console.log(this.fileData);
    this.uploadedFilePath = this.fileData.name;
    const formData = new FormData();
    formData.append('file', this.fileData);
    this.httpClient.post(this.utilsService.POST_SERVER_URL, formData)
      .subscribe(res => {
        //console.log(res);
        alert('SUCCESS !!');
        this.generateUML();

      })

  }

  generateUML() {
    let classAsString = "";
    //getting the file from the server
    this.getTypeScriptFile().subscribe((data: any) => {
      classAsString = data;
      console.log("Class as string : " + stringify(classAsString));
      this.className = this.getClassName(classAsString);
      console.log("got name:" + this.className);
      console.log("att list:" + stringify(this.attributes));
    });
  }

  getClassName(classAsString: string): string {
    let result = classAsString.split('class').pop().split('{')[0];
    return result;
  }

  getAttributes(classAsString: string): any[] {
    return;
  }

  getMethods(classAsString: string): any[] {
    return;
  }

  generateUMLDiagram(className: string) {

  }

  getTypeScriptFile(): any {
    console.log("getting the ts file");
    return this.httpClient.get(this.utilsService.BASE_SERVER_URL + "/" + this.utilsService.tsClassFileName, { responseType: 'text' });
  }


}
